import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity;


class Contato(var nome: String, var telefone: String, var email: String): AppCompatActivity() {

    override fun toString() : String{
        return "${this.nome} - ${this.telefone} - ${this.email}"
    }


}
