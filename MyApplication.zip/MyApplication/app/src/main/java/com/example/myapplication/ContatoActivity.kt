package com.example.myapplication

import Contato
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class ContatoActivity() : AppCompatActivity() {       // val lista : List<Contato> = mutableListOf()
    val lista = mutableListOf<Contato>()
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(R.layout.contato_layout)

        val txtNome = findViewById<EditText>(R.id.edtNome)
        val txtEmail = findViewById<EditText>(R.id.edtEmail)
        val txtFone = findViewById<EditText>(R.id.edtFone)

        val button = findViewById<Button>(R.id.btnSalvar)



        val listViewContato = findViewById<ListView>(R.id.lstContatos)
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        listViewContato.adapter = adapter



        button.setOnClickListener {
            val c1 = Contato(
                txtNome.text.toString(),
                txtFone.text.toString(),
                txtEmail.text.toString()
            )
            lista.add(c1)
            adapter.clear()
            for( contato in lista) {
                adapter.add(contato.toString())
            }
            Log.i("AGENDA_CONTATO", "Lista : ${lista}")
        }

    }
}