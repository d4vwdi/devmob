package com.example.aula05

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

public class Conversor : AppCompatActivity() {
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(R.layout.converter_activity)

        var edtMoeda = findViewById<EditText>(R.id.edtMoeda)
        var edtCotacao = findViewById<EditText>(R.id.edtCotacao)
        var txtResultado = findViewById<TextView>(R.id.txtResultado)
        val btnConverter = findViewById<Button>(R.id.btnConverter)

        btnConverter.setOnClickListener {
            var moeda = edtMoeda.text.toString().toFloat();
            var cotacao = edtCotacao.text.toString().toFloat();
            var resultado = moeda * cotacao

            txtResultado.text = "Resultado: ${resultado}"

        }




    }
}
